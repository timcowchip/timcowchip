#ifndef COMMON_INIT_H
#define COMMON_INIT_H
#include <string>

void init(char * const *argv);
#endif
