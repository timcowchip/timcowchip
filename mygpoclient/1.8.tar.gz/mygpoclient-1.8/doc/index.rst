
mygpoclient
===========

A gpodder.net client in Python
------------------------------

This reference manual describes how to utilize the mygpoclient API Client
Library to interface with the gpodder.net web service. The client library
provides a well-tested implementation that adheres to the.

This reference manual describes how to utilize the ``mygpoclient`` API Client
Library to interface with the gpodder.net web service. The client library
provides a well-tested implementation that adheres to the.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   manual
   mygpoclient


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
