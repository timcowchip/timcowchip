
unsigned short irda_fcs (unsigned char *blk_adr, unsigned long blk_len);
