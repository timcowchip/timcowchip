podcastparser: Simple, fast and efficient podcast parser
========================================================

The podcast parser project is a library from the gPodder project to provide an
easy and reliable way of parsing RSS- and Atom-based podcast feeds in Python.


## Automated Tests

To run the unit tests you need [`nose`](http://nose.readthedocs.io/en/latest/).  If you have `nose` installed, use the `nosetests` command in the repository's root directory to run the tests.
